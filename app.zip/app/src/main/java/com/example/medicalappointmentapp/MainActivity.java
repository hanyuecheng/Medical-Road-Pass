package com.example.medicalappointmentapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.SearchView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SearchView searchView = findViewById(R.id.search_view);

        // 处理搜索功能  
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                // 执行搜索逻辑  
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                // 根据输入的文本进行过滤  
                return false;
            }
        });

        Button buttonLogin = findViewById(R.id.button_login);
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 跳转到登录页面
                startActivity(new Intent(MainActivity.this, LoginActivity.class));
            }
        });

        Button buttonAppointment = findViewById(R.id.button_appointment);
        buttonAppointment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 跳转到挂号页面
                startActivity(new Intent(MainActivity.this, AppointmentActivity.class));
            }
        });

        Button buttonNews = findViewById(R.id.button_news);
        buttonNews.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 跳转到通知页面
                startActivity(new Intent(MainActivity.this, NewsActivity.class));
            }
        });

    }
}