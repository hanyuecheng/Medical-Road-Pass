package com.example.medicalappointmentapp;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class AppointmentActivity extends AppCompatActivity {

    private Spinner spinnerDoctor;
    private EditText editTextDate;
    private Button buttonSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointment);

        spinnerDoctor = findViewById(R.id.spinner_doctor);
        editTextDate = findViewById(R.id.editText_date);
        buttonSubmit = findViewById(R.id.button_submit);
        Button buttonLogout = findViewById(R.id.button_logout);

        // 模拟医生列表
        List<String> doctors = new ArrayList<>();
        doctors.add("医生A");
        doctors.add("医生B");
        doctors.add("医生C");

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, doctors);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDoctor.setAdapter(adapter);

        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 处理挂号业务逻辑
                String selectedDoctor = spinnerDoctor.getSelectedItem().toString();
                String appointmentDate = editTextDate.getText().toString();
                submitAppointment(selectedDoctor, appointmentDate);
            }
        });

        buttonLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 跳转回登录页面
                Intent intent = new Intent(AppointmentActivity.this, MainActivity.class);
                startActivity(intent);
                // 结束当前活动
                finish();
            }
        });


    }


    private void submitAppointment(String doctor, String date) {
        // TODO: 暂时只做 Toast，后续可以调用网络接口提交
        Toast.makeText(this, "成功预约医生: " + doctor + " 在时间: " + date, Toast.LENGTH_LONG).show();
    }
}